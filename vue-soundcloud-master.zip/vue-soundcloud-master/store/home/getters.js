export default {
  getTracksLoading: state => state.getTracksLoading,
  tracks: state => state.tracks,
  getTracksFail: state => state.getTracksFail,
  activeGenre: state => state.activeGenre,
  lastPage: state => state.lastPage,
};
