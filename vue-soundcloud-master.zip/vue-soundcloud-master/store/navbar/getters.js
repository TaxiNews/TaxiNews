export default {
  searchTracksLoading: state => state.searchTracksLoading,
  searchResults: state => state.searchResults,
  searchTracksFail: state => state.searchTracksFail,
  lastSearchPage: state => state.lastSearchPage,
  searchQuery: state => state.searchQuery,
};
