export default {
  isPlay: state => state.isPlay,
  playerCurrentTime: state => state.playerCurrentTime,
  playerDuration: state => state.playerDuration,
  playerTracks: state => state.playerTracks,
  playerCurrentTrack: state => state.playerCurrentTrack,
  playerSeeking: state => state.playerSeeking,
};
